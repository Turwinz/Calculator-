const calculator = document.querySelector('.calculator');
const display = document.getElementById('display-value');
const clearButton = document.querySelector('[data-action="clear"]');
const operatorButtons = document.querySelectorAll('.operator');

let state = {
    displayValue: '0',
    firstOperand: null,
    operator: null,
    waitingForSecondOperand: false,
};

function updateDisplay() {
    let formattedValue = state.displayValue;
    // Use comma as decimal separator like iOS
    if (formattedValue.includes('.')) {
        formattedValue = formattedValue.replace('.', ',');
    }
    
    // Add thousands separators, but handle comma for decimal correctly
    let parts = formattedValue.split(',');
    parts[0] = parseFloat(parts[0]).toLocaleString('en-US', { maximumFractionDigits: 20 });
    display.textContent = parts.join(',');

    // Auto-shrink font size if number is too long
    const displayContainer = document.querySelector('.display');
    const displayWidth = displayContainer.clientWidth;
    const textWidth = display.scrollWidth;
    const scale = Math.min(1, (displayWidth * 0.95) / textWidth);
    display.style.transform = `scale(${scale})`;

    // Toggle AC/C button text
    if (state.displayValue === '0' || state.waitingForSecondOperand) {
        clearButton.textContent = 'AC';
    } else {
        clearButton.textContent = 'C';
    }
}

function inputDigit(digit) {
    if (state.waitingForSecondOperand) {
        state.displayValue = digit;
        state.waitingForSecondOperand = false;
    } else {
        if (state.displayValue.length >= 15) return;
        state.displayValue = state.displayValue === '0' ? digit : state.displayValue + digit;
    }
    clearActiveOperator();
}

function inputDecimal() {
    if (state.waitingForSecondOperand) {
        state.displayValue = '0.';
        state.waitingForSecondOperand = false;
        return;
    }
    if (!state.displayValue.includes('.')) {
        state.displayValue += '.';
    }
}

function handleOperator(nextOperator) {
    const { firstOperand, displayValue, operator } = state;
    const inputValue = parseFloat(displayValue);

    if (operator && state.waitingForSecondOperand) {
        state.operator = nextOperator;
        setActiveOperator(nextOperator);
        return;
    }

    if (firstOperand === null) {
        state.firstOperand = inputValue;
    } else if (operator) {
        const result = calculate(firstOperand, operator, inputValue);
        state.displayValue = String(parseFloat(result.toPrecision(15)));
        state.firstOperand = result;
    }

    state.waitingForSecondOperand = true;
    state.operator = nextOperator;
    setActiveOperator(nextOperator);
}

function calculate(n1, operator, n2) {
    switch (operator) {
        case 'add': return n1 + n2;
        case 'subtract': return n1 - n2;
        case 'multiply': return n1 * n2;
        case 'divide': return n1 / n2;
        default: return n2;
    }
}

function resetCalculator() {
    state = {
        displayValue: '0',
        firstOperand: null,
        operator: null,
        waitingForSecondOperand: false,
    };
    clearActiveOperator();
}

function clearLastEntry() {
    state.displayValue = '0';
}

function toggleSign() {
    state.displayValue = String(parseFloat(state.displayValue) * -1);
}

function inputPercent() {
    state.displayValue = String(parseFloat(state.displayValue) / 100);
}

function setActiveOperator(action) {
    clearActiveOperator();
    if (action === 'equals') return;
    const button = document.querySelector(`[data-action="${action}"]`);
    if (button) {
        button.classList.add('active');
    }
}

function clearActiveOperator() {
    operatorButtons.forEach(btn => btn.classList.remove('active'));
}

calculator.addEventListener('click', e => {
    if (!e.target.matches('button')) return;
    const button = e.target;
    const { action, value } = button.dataset;

    if (value) {
        inputDigit(value);
    } else if (action === 'decimal') {
        inputDecimal();
    } else if (action === 'clear') {
        if (clearButton.textContent === 'AC') {
            resetCalculator();
        } else {
            clearLastEntry();
        }
    } else if (action === 'sign') {
        toggleSign();
    } else if (action === 'percent') {
        inputPercent();
    } else if (button.classList.contains('operator')) {
        handleOperator(action);
    }
    
    updateDisplay();
});


// Initial setup
updateDisplay();

